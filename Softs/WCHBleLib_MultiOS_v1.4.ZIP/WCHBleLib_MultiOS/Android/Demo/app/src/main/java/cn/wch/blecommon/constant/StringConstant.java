package cn.wch.blecommon.constant;

public class StringConstant {
    public static final String BTN_TEST_START="开始测试";
    public static final String BTN_TEST_STOP="结束测试";

    public static final String BTN_SEND="发送";
    public static final String BTN_STOP="停止";
}
