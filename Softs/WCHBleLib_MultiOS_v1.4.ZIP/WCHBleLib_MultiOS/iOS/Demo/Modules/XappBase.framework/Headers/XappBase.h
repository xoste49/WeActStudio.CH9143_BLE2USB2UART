//
//  XappBase.h
//  XappBase
//
//  Created by jiangjing on 7/5/18.
//  Copyright © 2018 cnspirit.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XappBase.
FOUNDATION_EXPORT double XappBaseVersionNumber;

//! Project version string for XappBase.
FOUNDATION_EXPORT const unsigned char XappBaseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XappBase/PublicHeader.h>

