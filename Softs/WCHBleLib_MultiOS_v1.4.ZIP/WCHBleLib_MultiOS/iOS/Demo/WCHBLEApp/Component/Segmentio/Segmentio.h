//
//  Segmentio.h
//  Segmentio
//
//  Created by Dmitriy Demchenko on 7/11/16.
//  Copyright © 2016 Yalantis. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Segmentio.
FOUNDATION_EXPORT double SegmentioVersionNumber;

//! Project version string for Segmentio.
FOUNDATION_EXPORT const unsigned char SegmentioVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Segmentio/PublicHeader.h>


