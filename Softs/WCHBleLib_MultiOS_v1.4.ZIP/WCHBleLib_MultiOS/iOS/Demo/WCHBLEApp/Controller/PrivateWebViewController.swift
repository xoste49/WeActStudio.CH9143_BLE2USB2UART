//
//  PrivateWebViewController.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/4/7.
//

import UIKit
import XappKit
import XappBase
import WebKit

class PrivateWebViewController: MH_VC_BaseViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let filepath = Bundle.main.path(forResource: "private", ofType: "html")
        {
            do
            {
                let contents = try String(contentsOfFile: filepath)
                print(contents)
                let url = URL.init(fileURLWithPath: filepath)
                self.webView.loadFileURL(url, allowingReadAccessTo: url)
            }
            catch
            {
                print("Contents could not be loaded.")
            }
        }
        else
        {
            print("newTest.txt not found.")
        }
    }


  

}
