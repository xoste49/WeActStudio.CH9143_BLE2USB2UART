const app = getApp()

const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

function GetTime(){
  var n, now_time='';
  n = new Date();
  now_time += n.getFullYear();
  now_time += ':'+(n.getMonth()+1);
  now_time += ':'+n.getDate();
  now_time += '  '+n.getHours();
  now_time += ':'+n.getMinutes();
  now_time += ':'+n.getSeconds();
  now_time += ':'+n.getMilliseconds();
  // now_time += ':';
  return( now_time );
}

/*微信app版本比较*/
function versionCompare(ver1, ver2) {
  var version1pre = parseFloat(ver1)
  var version2pre = parseFloat(ver2)
  var version1next = parseInt(ver1.replace(version1pre + ".", ""))
  var version2next = parseInt(ver2.replace(version2pre + ".", ""))
  if (version1pre > version2pre)
    return true
  else if (version1pre < version2pre)
    return false
  else {
    if (version1next > version2next)
      return true
    else
      return false
  }
}


module.exports = {
  formatTime: formatTime,
  GetTime,
  versionCompare: versionCompare,
}
