
function codeWithInfo(code) {
  var errorInfo="";
  switch (code){
    case 10000 :
      errorInfo ="10000,未初始化蓝牙适配器";
      break;
    case 10001:
      errorInfo = "10001,当前蓝牙适配器不可用";
      break;
    case 10002:
      errorInfo = "10002,没有找到指定设备";
      break;
    case 10003:
      errorInfo = "10003,连接失败";
      break;
    case 10004:
      errorInfo = "10004,没有找到指定服务";
      break;
    case 10005:
      errorInfo = "10005,没有找到指定特征值";
      break;
    case 10006:
      errorInfo = "10006,当前连接已断开";
      break;
    case 10007:
      errorInfo = "10007,当前特征值不支持此操作";
      break;
    case 10008:
      errorInfo = "10008,其余所有系统上报的异常";
      break;
    case 10009:
      errorInfo = "10009,Android系统版本低于 4.3不支持BLE";
      break;
    case 10012:
      errorInfo = "10012,连接超时";
    case 10013:
      errorInfo = "10013,连接 deviceId为空或者是格式不正确";
      break;
  }
  return errorInfo;
}

module.exports = {
  codeWithInfo: codeWithInfo
}