Page({
  data: {
   isPopping: false,
   animPlus: {},
   animCollect: {},
   animTranspond: {},
   animInput: {},
   animCloud:{},
   aninWrite:{},
   showFlag:false
  },
  //点击弹出

  plus: function (num) {
      if(num==1){
        this.setData({
          isPopping:  false,
          showFlag: false
         })

      }else{
        this.setData({
          isPopping:  !this.data.isPopping,
          showFlag: !this.data.showFlag
         })

      }
    
    this.triggerEvent('menuItemClick', {
      isPopping:this.data.isPopping
  })
    if (this.data.isPopping) {
     this.popp();
    } else if (!this.data.isPopping) {
     this.takeback();
    }
  },
  itemclick:function(e){
    let info = e.currentTarget.dataset.name;
    this.triggerEvent('menuItemClick', {
      "iteminfo":info
  })
    this.plus()
  },

  
  
  //弹出动画
  popp: function () {
   //plus顺时针旋转
   var animationPlus = wx.createAnimation({
    duration:400,
    timingFunction: 'ease-out'
   })
   var animationcollect = wx.createAnimation({
    duration: 400,
    timingFunction: 'ease-out'
   })
   animationPlus.rotateZ(180).step();
   animationcollect.opacity(1).step();
   this.setData({
    animPlus: animationPlus.export(),
    animCollect: animationcollect.export(),
   })
  },
  //收回动画
  takeback: function () {
   //plus逆时针旋转
   var animationPlus = wx.createAnimation({
    duration: 10,
    timingFunction: 'ease-out'
   })
   var animationcollect = wx.createAnimation({
    duration: 10,
    timingFunction: 'ease-out'
   })
   animationPlus.rotateZ(0).step();
   animationcollect.opacity(0).step();
   this.setData({
    animPlus: animationPlus.export(),
    animCollect: animationcollect.export(),
   })
  },
  
  
  onLoad: function (options) {
   // 生命周期函数--监听页面加载
  },
  onReady: function () {
   // 生命周期函数--监听页面初次渲染完成
  },
  onShow: function () {
   // 生命周期函数--监听页面显示
  },
  onHide: function () {
   // 生命周期函数--监听页面隐藏
  },
  onUnload: function () {
   // 生命周期函数--监听页面卸载
  },
  onPullDownRefresh: function () {
   // 页面相关事件处理函数--监听用户下拉动作
  },
  onReachBottom: function () {
   // 页面上拉触底事件的处理函数
  },
  onShareAppMessage: function () {
  }
 })