//
//  AppDelegate.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/3/16.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    /**
     * UI的全局配置
     */
    func apperanceCustom() {
        //导航栏配置
        XAPPTheme.configNavigationBarStyle()
        XAPPTheme.configTabBarStyle()
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
            
        self.apperanceCustom()
        
        self.window = UIWindow.init(frame: UIScreen.main.bounds)
        let homeVC = HomeViewController.init(nibName: "HomeViewController", bundle: Bundle.init(for: HomeViewController.self))
        let navHome = UINavigationController.init(rootViewController: homeVC)
        self.window?.rootViewController = navHome
        self.window?.makeKeyAndVisible()
        
        return true
    }


}

