﻿#ifndef  _WCHBLEDLL_H
#define  _WCHBLEDLL_H

#define uint128_t GUID

#ifdef __cplusplus
extern "C" {
#endif

typedef PVOID WCHBLEHANDLE;											//BLE设备句柄

typedef struct	_BLENameDevID										//设备扫描信息结构体
{
	UCHAR			Name[MAX_PATH];									//蓝牙设备名称
	UCHAR			DevID[MAX_PATH];								//蓝牙设备路径
	INT				Rssi;											//蓝牙设备RSSI(信号强度)
} BLENameDevID, * pBLENameDevID;

typedef struct _BLEAdvData											//广播PDU数据段信息结构体
{
	UCHAR			Type;											//PDU数据段类型
	INT				DataLen;										//PDU数据段数据长度
	UCHAR			AdvData[MAX_PATH];								//PDU数据段内容
} BLEAdvData, * pBLEAdvData;

typedef struct _BLEAdvAttribute										//广播包属性信息结构体
{
	/* AdvType:
		ConnectableUndirected = 0,    非定向可连接广播包
		ConnectableDirected = 1,	  定向可连接广播包
		ScannableUndirected = 2,	  非定向可扫描广播包
		NonConnectableUndirected = 3, 不可连接的非定向广播包
		ScanResponse = 4,			  扫描响应包
		Extended = 5,
	*/
	INT				AdvType;										//指示广播包类型
	BOOL			IsConnectable;									//指示发送广播包的设备是否可连接
	BOOL			IsScannable;									//指示收到的播发是否可扫描
	BOOL			IsDirected;										//指示发送广播包的设备是否定向播发
	BOOL			IsAnonymous;									//指定设备地址是否包含在播发标头中
	BOOL			IsScanResponse;									//指示收到的播发是否为扫描响应
	LONGLONG		TimeStamp;										//指示收到的广播包时间戳(单位:100ns)
	INT				TimeSpace;										//指示收到的广播包时间间隔(单位:100ns)
} BLEAdvAttribute, * pBLEAdvAttribute;

typedef struct _BLEAdvPacket										//广播包信息结构体
{
	BLEAdvAttribute AdvAttribute;									//广播包属性结构体
	INT				PacketNum;										//广播PDU数据段数量
	BLEAdvData		AdvData[16];									//广播PDU数据段信息结构体
} BLEAdvPacket, * pBLEAdvPacket;

typedef struct _BLEAdvertisingDev									//广播扫描信息结构体
{
	UCHAR			MAC[6];											//广播设备地址
	/* AddressType:
		Public = 0,  公有地址
		Random = 1,  随机地址
		Unspecified = 2,
	*/
	INT				AddressType;									//广播设备地址类型
	BLEAdvPacket	AdvPacket[16];									//广播包信息结构体
	//std::vector<BLEAdvPacket> AdvPacket;
	INT				Rssi;											//广播设备RSSI(信号强度)
} BLEAdvertisingDev, * pBLEAdvertisingDev;

typedef		VOID	( CALLBACK	* pFunReadCallBack ) (				//特征值订阅读数据上报回调函数
	PVOID			ParamInf,										//PVOID类型的设备句柄(WCHBLEHANDLE),在多连接是指定是哪个设备上报的数据
	PCHAR			ReadBuf,										//指向一个缓冲区,提供已订阅特征值上报的数据
	ULONG			ReadBufLen );									//指定已订阅特征值上报的数据长度

typedef		VOID	( CALLBACK	* pFunDevConnChangeCallBack ) (		//设备连接状态改变回调函数
	PVOID			hDev,											//PVOID类型的设备句柄(WCHBLEHANDLE),在多连接是指定是哪个设备上报的连接状态
	UCHAR			ConnectStatus );								//此变量指示连接状态:0x00-断开;0x01-连接

typedef		INT	( CALLBACK	* pFunDevPairCallBack ) (				//设备配对事件回调函数			返回1表示输入内容尝试连接   返回0表示取消输入 停止配对流程
	PVOID			hDev,											//PVOID类型的设备句柄(WCHBLEHANDLE),在多连接是指定是哪个设备上报的配对事件
	PCHAR			DevAddr,										//指向上报事件的设备地址的缓冲区
	ULONG			RequestType,									//上报的配对事件类型
	PCHAR			ConfirmData );									//指向需要展示配对PIN码数据的缓冲区

typedef		VOID	( CALLBACK	* pFunRSSICallBack ) (				//设备RSSI(信号强度)回调函数
	PCHAR			pMAC,											//指向上报RSSI的设备地址的缓冲区
	INT				rssi );											//RSSI值,指示信号强度

typedef		VOID	( CALLBACK* pFunAdvertisingCallBack ) (			//广播扫描设备回调函数
	BLEAdvertisingDev BLEAdvDevInfo);								//广播扫描信息结构体


VOID	WINAPI	WCHBLEInit( );										//WCHBLEDLL库初始化函数

BOOL	WINAPI	WCHBLEIsBluetoothOpened( );							//查询系统蓝牙是否打开

UCHAR	WINAPI	WCHBLEGetBluetoothVer( );							//查询蓝牙控制器版本

BOOL	WINAPI	WCHBLEIsLowEnergySupported( );						//查询蓝牙控制器是否支持低功耗蓝牙(BLE)设备

BOOL	WINAPI	WCHBLEIsPeripheralRoleSupported( );					//查询蓝牙控制器是否支持LE外围设备 

BOOL	WINAPI	WCHBLEIsCentralRoleSupported( );					//查询蓝牙控制器是否支持LE中心设备

BOOL	WINAPI	WCHBLEAreLowEnergySecureConnectionsSupported( );	//查询蓝牙控制器是否支持低功耗蓝牙(BLE)的安全连接

BOOL	WINAPI	WCHBLEIsAdvertisementOffloadSupported( );			//查询蓝牙控制器是否支持加载广播包

VOID	WINAPI	WCHBLEEnumPairedDevice(								//枚举系统已配对蓝牙设备
	BLENameDevID*	pBLENameDevIDArry,								//指向用于接收枚举设备信息结构体的指针
	PULONG			pNum );											//指向枚举设备数量单元,输入时为准备获取到的设备数量,返回后为实际枚举到的设备数量

VOID	WINAPI	WCHBLEEnumDevice(									//枚举可操作的BLE设备
	ULONG			scanTimes,										//设备枚举持续时间(单位:ms)
	PCHAR			DevNameFilter,									//设备名称过滤字符串
	BLENameDevID*	pBLENameDevIDArry,								//指向用于接收枚举设备信息结构体的指针
	PULONG			pNum );											//指向枚举设备数量单元,输入时为准备获取到的设备数量,返回后为实际枚举到的设备数量

UCHAR	WINAPI	WCHBLEEnumAdvertisingDevice(						//枚举正在发送广播的蓝牙设备
	ULONG			scanTimes,										//广播设备枚举持续时间(单位:ms)
	BLEAdvertisingDev* pBLEAdvDevArry,								//指向用于接收枚举广播设备信息结构体的指针
	PULONG			pNum );											//指向枚举设备数量单元,输入时为准备获取到的设备数量,返回后为实际枚举到的设备数量

UCHAR	WINAPI	WCHBLERegisterAdvertisingNotify(					//注册/关闭获取广播设备订阅
	pFunAdvertisingCallBack pFun);									//指定发现广播设备上报事件回调(pFun参数为NULL时代表关闭订阅)

VOID	WINAPI	WCHBLEEnumCH914X(									//枚举CH914X系列设备
	ULONG			scanTimes,										//设备枚举持续时间(单位:ms)
	BLENameDevID*	pBLENameDevIDArry,								//指向用于接收枚举设备信息结构体的指针
	PULONG			pNum );											//指向枚举设备数量单元,输入时为准备获取到的设备数量,返回后为实际枚举到的设备数量

/* DevicePairingKind:
	ConfirmOnly = 1; //用户确认配对
	DisplayPin = 2; //展示PIN码给用户
	ProvidePin = 4; //请求PIN码输入
	ConfirmPinMatch = 8; //请求用户确认PIN码
*/
BOOL	WINAPI	WCHBLEPairDevice(									//通过设备地址发起指定类型的配对请求
	PCHAR			deviceAddr,										//指向需要配对的设备的地址缓冲区
	INT				DevicePairingKind,								//指定蓝牙设备配对类型
	pFunDevPairCallBack pFunDevPair );								//指定设备配对事件回调
	
BOOL	WINAPI	WCHBLEPairAllKindDevice(							//通过设备地址发起配对请求
	PCHAR			deviceAddr,										//指向需要配对的设备的地址缓冲区
	pFunDevPairCallBack pFunDevConnChange );						//指定设备配对事件回调

VOID	WINAPI	WCHBLEConfirmPairData(								//根据配对类型确认/输入设备配对信息
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	PCHAR			ConfirmData );									//指向输入的PIN码或秘钥数据的缓冲区

BOOL	WINAPI	WCHBLEUnpairDevice(									//解除指定地址的设备的配对绑定
	PCHAR			deviceAddr );									//指向需要解除配对的设备的地址缓冲区

WCHBLEHANDLE	WINAPI	WCHBLEOpenDevice(							//通过设备路径打开指定设备
	PCHAR			deviceID,										//指向需要打开的设备的路径缓冲区
	BOOL			IsCacheMode,									//指定打开设备的缓存模式(FALSE:非缓存模式,此模式下打开设备会尝试与设备建立真实连接,如果出现异常则会返回NULL;TRUE:缓存模式,此模式下如果无法和设备建立真实连接,会返回可以读取缓存在系统中的设备信息的设备句柄)
	pFunDevConnChangeCallBack pFunDevConnChange );					//指定设备连接状态事件回调

WCHBLEHANDLE	WINAPI	WCHBLEOpenDeviceAddress(					//通过设备地址打开指定设备
	PCHAR			deviceAddr,										//指向需要配对的设备的地址缓冲区
	BOOL			IsCacheMode,									//指定打开设备的缓存模式(FALSE:非缓存模式,此模式下打开设备会尝试与设备建立真实连接,如果出现异常则会返回NULL;TRUE:缓存模式,此模式下如果无法和设备建立真实连接,会返回可以读取缓存在系统中的设备信息的设备句柄)
	pFunDevConnChangeCallBack pFunDevConnChange );					//指定设备连接状态事件回调

VOID	WINAPI	WCHBLECloseDevice(									//关闭设备连接
	WCHBLEHANDLE	pDev );											//BLE设备句柄

UCHAR	WINAPI	WCHBLEGetAllServicesUUID(							//获取设备所有服务UUID(16位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	PUSHORT			pUUIDArry,										//指向一个足够大的数组,用于保存获取到的服务UUID(16位)
	PUSHORT			pUUIDArryLen );									//指向数量单元,输入时为准备获取的服务数量,返回后为实际获取到的服务数量

UCHAR	WINAPI	WCHBLEGetAllServicesUUID_128(						//获取设备所有服务UUID(128位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	uint128_t*		pUUIDArry,										//指向一个足够大的数组,用于保存获取到的服务UUID(128位)
	PUSHORT			pUUIDArryLen );									//指向数量单元,输入时为准备获取的服务数量,返回后为实际获取到的服务数量

UCHAR	WINAPI	WCHBLEGetCharacteristicByUUID(						//获取指定服务的所有特征值UUID(16位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	USHORT			ServiceUUID,									//16位服务UUID
	PUSHORT			pUUIDArry,										//指向一个足够大的数组,用于保存获取到的指定服务的特征值UUID(16位)
	PUSHORT			pUUIDArryLen );									//指向数量单元,输入时为准备获取的特征值数量,返回后为实际获取到的特征值数量

UCHAR	WINAPI	WCHBLEGetCharacteristicByUUID_128(					//获取指定服务的所有特征值UUID(128位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	uint128_t		ServiceUUID,									//128位服务UUID
	uint128_t*		pUUIDArry,										//指向一个足够大的数组,用于保存获取到的指定服务的特征值UUID(128位)
	PUSHORT			pUUIDArryLen );									//指向数量单元,输入时为准备获取的特征值数量,返回后为实际获取到的特征值数量

/*
pAction:
位0为1(0x01) :Broadcast
位1为1(0x02) :Read
位2为1(0x04) :WriteWithoutResponse
位3为1(0x08) :Write
位4为1(0x10) :Notify
位5为1(0x20) :Indicate
位6为1(0x40) :AuthenticatedSignedWrites
位7为1(0x80) :ExtendedProperties
位8为1(0x100) :ReliableWrites
位9为1(0x200) :WritableAuxiliaries
*/
UCHAR	WINAPI	WCHBLEGetCharacteristicAction(						//获取指定特征值的可操作属性(16位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	USHORT			ServiceUUID,									//16位服务UUID
	USHORT			CharacteristicUUID,								//16位特征值UUID
	PULONG			pAction,										//指向属性单元,表示指定特征值允许的操作
	PUSHORT			AttributeHandle );								//指定特征值的属性句柄
	
UCHAR	WINAPI	WCHBLEGetCharacteristicAction_128(					//获取指定特征值的可操作属性(128位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	uint128_t		ServiceUUID,									//128位服务UUID
	uint128_t		CharacteristicUUID,								//128位特征值UUID
	PULONG			pAction,										//指向属性单元,表示指定特征值允许的操作
	PUSHORT			AttributeHandle );								//指定特征值的属性句柄

UCHAR	WINAPI	WCHBLEWriteCharacteristic(							//针对指定特征值进行写操作(16位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	USHORT			ServiceUUID,									//16位服务UUID
	USHORT			CharacteristicUUID,								//16位特征值UUID
	BOOL			bWriteWithResponse,								//表示是否以有应答方式写特征值(TRUE:有应答方式写,函数返回时表示已完成写操作;FALSE:无应答方式写,函数会立刻返回,数据由系统蓝牙控制器调配发送)
	PCHAR			buffer,											//指向一个缓冲区,放置准备写出的数据
	UINT			length );										//表示需要写的数据长度

UCHAR	WINAPI	WCHBLEWriteCharacteristic_128(						//针对指定特征值进行写操作(128位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	uint128_t		ServiceUUID,									//128位服务UUID
	uint128_t		CharacteristicUUID,								//128位特征值UUID
	BOOL			bWriteWithResponse,								//表示是否以有应答方式写特征值(TRUE:有应答方式写,函数返回时表示已完成写操作;FALSE:无应答方式写,函数会立刻返回,数据由系统蓝牙控制器调配发送)
	PCHAR			buffer,											//指向一个缓冲区,放置准备写出的数据
	UINT			length );										//表示需要写的数据长度

UCHAR	WINAPI	WCHBLEReadCharacteristic(							//针对指定特征值进行读操作(16位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	USHORT			ServiceUUID,									//16位服务UUID
	USHORT			CharacteristicUUID,								//16位特征值UUID
	PCHAR			buffer,											//指向一个足够大的缓冲区,用于保存读取的数据
	PUINT			length );										//指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度

UCHAR	WINAPI	WCHBLEReadCharacteristic_128(						//针对指定特征值进行读操作(128位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	uint128_t		ServiceUUID,									//128位服务UUID
	uint128_t		CharacteristicUUID,								//128位特征值UUID
	PCHAR			buffer,											//指向一个足够大的缓冲区,用于保存读取的数据
	PUINT			pLength );										//指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度

UCHAR	WINAPI	WCHBLERegisterReadNotify(							//针对指定特征值进行订阅操作(16位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	USHORT			ServiceUUID,									//16位服务UUID
	USHORT			CharacteristicUUID,								//16位特征值UUID
	pFunReadCallBack pFun,											//指定设备数据上报事件回调
	PVOID			paramInf );

UCHAR	WINAPI	WCHBLERegisterReadNotify_128(						//针对指定特征值进行订阅操作(128位)
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	uint128_t		ServiceUUID,									//128位服务UUID
	uint128_t		CharacteristicUUID,								//128位特征值UUID
	pFunReadCallBack pFun,											//指定设备数据上报事件回调
	PVOID			paramInf );

UCHAR	WINAPI	WCHBLERegisterRSSINotify(							//注册/关闭获取设备RSSI(信号强度)订阅
	pFunRSSICallBack pFun );										//指定设备数据上报事件回调(pFun参数为NULL时代表关闭订阅)

UCHAR	WINAPI	WCHBLEGetMtu(										//获取本次连接MTU的大小
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	PUSHORT			pMTU );											//指向数据单元,用于保存获取到的设备MTU值

/*
pProtectionLevel：0
Uses the default protection level.
pProtectionLevel：1
Require the link to be authenticated.
pProtectionLevel：2
Require the link to be encrypted.
pProtectionLevel：3
Require the link to be encrypted and authenticated.
*/
UCHAR	WINAPI	WCHBLEGetCharacteristicProtectionLevel(				//获取指定特征值的保护等级
	WCHBLEHANDLE	pDev,											//BLE设备句柄
	USHORT			ServiceUUID,									//16位服务UUID
	USHORT			CharacteristicUUID,								//16位特征值UUID
	PUCHAR			pProtectionLevel );								//指向数据单元,用于保存获取到的保护等级值

/// <summary>
/// 查询系统版本信息
/// </summary>
/// <param name="requiredMajor"></param>
/// <param name="requiredMinor"></param>
/// <param name="requiredBuild"></param>
/// <returns></returns>
BOOL WINAPI IsWindowsBuildAtLeast(int requiredMajor, int requiredMinor, int requiredBuild);

#ifdef __cplusplus
}
#endif

#endif