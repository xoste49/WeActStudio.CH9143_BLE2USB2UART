//
//  NewPeripheralCell.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/4/6.
//

import UIKit

class NewPeripheralCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
