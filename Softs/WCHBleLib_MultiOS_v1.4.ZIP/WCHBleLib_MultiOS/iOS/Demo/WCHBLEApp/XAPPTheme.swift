//
//  MYCTheme.swift
//  RJ-MiYuCai
//
//  Created by jiangjing on 5/5/16.
//  Copyright © 2016 cnspirit.com. All rights reserved.
//

import Foundation
import UIKit
import XappKit

public struct XAPPTheme {
    
    //MARK:  color
    //主色调
    let mainBlueColor = UIColor(hexString: "#202649")//主蓝色
    //辅助色
    let vicePurpleColor = UIColor(hexString: "#5a5498")//副紫色
    let viceYellowColor = UIColor(hexString: "#ffb51c")//副黄色
    let vicePinkColor = UIColor(hexString: "#ff2569")//副粉色
    let viceRedColor = UIColor(hexString: "#f02c18")//副红色
    let viceBlueColor = UIColor(hexString: "#202649")//副深蓝色
    
    //主要文本颜色
    let GrayTextColor = UIColor(hexString: "#999999")     //时间文字颜色 灰色
    let BlackTextColor = UIColor(hexString: "#000000")    //文字黑色
    let whiteTextColor = UIColor(hexString: "#ffffff")    //文字白色
    
    let placeholderColor = UIColor(hexString: "#999999")                      //占位文字颜色
    let segmentLitTitleColor = UIColor.init(hexString: "#ffffff", alpha: 0.5) //segment文字白色 小字 透明度0.5
    let segmentBigTitleColor = UIColor(hexString: "#ffffff")                  //segment文字白色 大字 透明度1
    let smartSegmentLitColor = UIColor.init(hexString: "#000000", alpha: 0.4) //小segment文字白色 小字 透明度0.4
    let smartSegmentBigColor = UIColor(hexString: "#316db5")                  //小segment文字白色 大字 透明度1
    let backgroundColor = UIColor(hexString: "#404b59")           //背景色
    let backgroundColor1 = UIColor(hexString: "#f4f6f9")           //背景色

    
    //font size
    let mainFontSize = UIFont.systemFont(ofSize: 14.0)              //正文字号
    let mainFon = UIFont.systemFont(ofSize: 14.0)
    let littleFontSize = UIFont.systemFont(ofSize: 10.0)            // 小字字号
    
    let littleImageFontSize = UIFont.systemFont(ofSize: 12.0)        //小图片上文字字号
    let bigImageFontSize = UIFont.systemFont(ofSize: 16.0)           //大图片上文字字号
    
    let NavFontSize = UIFont.systemFont(ofSize: 15.0)               //导航栏字号
    let timeFontSize = UIFont.systemFont(ofSize: 11.0)               //时间字号
    let segmentLitTitleSize = UIFont.systemFont(ofSize: 15.0)         //segment文字小字字号
    let segmentBigTitleSize = UIFont.systemFont(ofSize: 17.0)        //segment文字大字字号
    let smartSegmentLitSize = UIFont.systemFont(ofSize: 14.0)        //小segment文字小字字号
    let smartSegmentBigSize = UIFont.systemFont(ofSize: 15.0)        //小segment文字大字字号
    
    let talkTextSize = UIFont.systemFont(ofSize: 13.0)               //聊天室文字字号 & 弹幕文字字号
    let placeholderFontSize = UIFont.systemFont(ofSize: 14.0)       //登录占位符字号
    let SearchplaceholderSize = UIFont.systemFont(ofSize: 11.0)     //搜索占位符字号
    let talkPlaceholderSize = UIFont.systemFont(ofSize: 13.0)     //聊天室占位符字号

    
    let isBigScreenSize = (UIScreen.main.bounds.size.height <= 812 ? false : true)   //是否是大屏   苹果8及以下
    let ScreenWidth = UIScreen.main.bounds.size.width   //屏幕宽度
    //MARK: 配置
    static func configNavigationBarStyle () {
        //导航栏配置
        UINavigationBar.appearance().barTintColor = UIColor.init(r: 42, g: 140, b: 205)
        UINavigationBar.appearance().tintColor = UIColor.white //UIColor.init(hexString: "f8652b")
//        UINavigationBar.appearance().barStyle = UIBarStyle.black; //
        UINavigationBar.appearance().isTranslucent = false
        let titleColor = UIColor.white //UIColor.init(hexString: "fb652b")
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor : titleColor, NSAttributedString.Key.font : UIFont.systemFont(ofSize: 18.0)]
        
//        let gradient = CAGradientLayer()
//        let sizeLength = UIScreen.main.bounds.size.width
//        let defaultNavigationBarFrame = CGRect(x: 0, y: 0, width: sizeLength, height: 80)
//
//        gradient.frame = defaultNavigationBarFrame
//        gradient.colors = [UIColor.init(r: 150, g: 80, b: 200).cgColor, UIColor.init(r: 110, g: 80, b: 200).cgColor]
        
        UINavigationBar.appearance().setBackgroundImage(UIImage.init(named: "navgation_top_bg"), for: .default)

    }
    
    static func configTabBarStyle() {
        //Tabbar
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.init(hexString: "#959595", alpha: 0.6) as Any], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : XAPPTheme().viceRedColor as Any], for: .selected)
        UITabBar.appearance().barTintColor = UIColor.white
        UITabBar.appearance().backgroundColor = UIColor.white
        UITabBar.appearance().isTranslucent = false
        UITabBar.appearance()

        //tintcolor 会改变选中的tabitem 图片颜色
        // UITabBar.appearance().tintColor =  UIColor(red: 70.0 / 255.0, green: 200.0 / 255.0, blue: 90.0 / 255.0, alpha: 1.0)
 
    }
    
    //设置状态栏背景颜色
    static func setStatusBarBackgroundColor(color : UIColor) {
        
        let statusBarWindow : UIView = UIApplication.shared.value(forKey: "statusBarWindow") as! UIView
        let statusBar : UIView = statusBarWindow.value(forKey: "statusBar") as! UIView
        if statusBar.responds(to: #selector(setter:UIView.backgroundColor)){
            statusBar.backgroundColor = color
        }
    }
}

