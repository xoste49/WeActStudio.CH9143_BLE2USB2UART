function  downFile(path,name) {//下载文件
  let that= this;
  const FileSystemManager = wx.getFileSystemManager()
  console.log(path,name)

  return new Promise((resolve,reject) =>{
    
    FileSystemManager.saveFile({//下载成功后保存到本地
      tempFilePath:path,
      filePath: wx.env.USER_DATA_PATH + "/" + name,
      success(res2) {
        console.log(res2,'保存')
        if (res2.errMsg == 'saveFile:ok') {

          FileSystemManager.readFile({ //读文件
            filePath: wx.env.USER_DATA_PATH + "/" + name,
            encoding: 'utf8',
            success(res) {
              if (res.data) {
                // console.log(res.data,'读取文件')
                resolve(res)
              }
            },
            fail(err) {
              console.log('读取失败', err)
              reject(err)
            }
          })

        }else{ 
          reject()
        
        }
      },
      fail(err) {
        reject(err)
       
      }
    })
  }).catch((err) => {
    console.log("加载失败")
  })


}

module.exports = {
  downFile:  downFile,
}
